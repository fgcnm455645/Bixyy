package com.bxt.edgeglow;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Samsung-style color picker: Swatches / Spectrum tabs, Hex + RGB fields and recently used colors. */
final class Picker {
    interface Callback {
        void onPicked(int color);
    }

    static final int COLS = 13, ROWS = 12;
    static final float[] HUES = {0f, 25f, 45f, 60f, 95f, 140f, 175f, 210f, 235f, 275f, 305f, 335f};
    static final int CARD = 0xFF2D2D30;
    static final int PILL = 0xFF4C4C50;
    static final int GRAY = 0xFFA0A0A6;
    static Bitmap SPEC;

    static int hsl(float h, float s, float l) {
        float c = (1f - Math.abs(2f * l - 1f)) * s;
        float hp = (h % 360f) / 60f;
        float x = c * (1f - Math.abs(hp % 2f - 1f));
        float r = 0f, g = 0f, b = 0f;
        if (hp < 1f) {
            r = c;
            g = x;
        } else if (hp < 2f) {
            r = x;
            g = c;
        } else if (hp < 3f) {
            g = c;
            b = x;
        } else if (hp < 4f) {
            g = x;
            b = c;
        } else if (hp < 5f) {
            r = x;
            b = c;
        } else {
            r = c;
            b = x;
        }
        float m = l - c / 2f;
        return 0xFF000000 | (Math.round((r + m) * 255f) << 16) | (Math.round((g + m) * 255f) << 8)
                | Math.round((b + m) * 255f);
    }

    static float[] toHsl(int c) {
        float r = ((c >> 16) & 255) / 255f, g = ((c >> 8) & 255) / 255f, b = (c & 255) / 255f;
        float mx = Math.max(r, Math.max(g, b)), mn = Math.min(r, Math.min(g, b));
        float l = (mx + mn) / 2f, h = 0f, s = 0f, dd = mx - mn;
        if (dd > 1e-6f) {
            s = dd / (1f - Math.abs(2f * l - 1f));
            if (mx == r) h = ((g - b) / dd) % 6f;
            else if (mx == g) h = (b - r) / dd + 2f;
            else h = (r - g) / dd + 4f;
            h *= 60f;
            if (h < 0f) h += 360f;
        }
        return new float[]{h, s, l};
    }

    // ---------- 13 x 12 swatch grid ----------
    static class SwatchGrid extends View {
        interface L {
            void on(int color);
        }

        private final float d;
        private final int[][] cell = new int[COLS][ROWS];
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path clip = new Path();
        private final RectF r = new RectF();
        private int selC = -1, selR = -1;
        private L listener;

        SwatchGrid(Context c) {
            super(c);
            d = c.getResources().getDisplayMetrics().density;
            for (int row = 0; row < ROWS; row++) {
                int gv = Math.round((1f - row / (float) (ROWS - 1)) * 255f);
                cell[0][row] = 0xFF000000 | (gv << 16) | (gv << 8) | gv;
                float l = 0.95f - row * (0.83f / (ROWS - 1));
                for (int ci = 1; ci < COLS; ci++) cell[ci][row] = hsl(HUES[ci - 1], 1f, l);
            }
        }

        void setListener(L l) {
            listener = l;
        }

        void select(int color) {
            selC = -1;
            selR = -1;
            int c = color | 0xFF000000;
            for (int ci = 0; ci < COLS; ci++) {
                for (int row = 0; row < ROWS; row++) {
                    if (cell[ci][row] == c) {
                        selC = ci;
                        selR = row;
                    }
                }
            }
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            float cw = w / COLS, ch = h / ROWS;
            clip.reset();
            r.set(0, 0, w, h);
            clip.addRoundRect(r, 14 * d, 14 * d, Path.Direction.CW);
            c.save();
            c.clipPath(clip);
            p.setStyle(Paint.Style.FILL);
            for (int ci = 0; ci < COLS; ci++) {
                for (int row = 0; row < ROWS; row++) {
                    p.setColor(cell[ci][row]);
                    c.drawRect(ci * cw, row * ch, (ci + 1) * cw + 0.6f, (row + 1) * ch + 0.6f, p);
                }
            }
            c.restore();
            if (selC >= 0) {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(2.5f * d);
                p.setColor(0xFFFFFFFF);
                r.set(selC * cw + 1.5f * d, selR * ch + 1.5f * d, (selC + 1) * cw - 1.5f * d,
                        (selR + 1) * ch - 1.5f * d);
                c.drawRoundRect(r, 6 * d, 6 * d, p);
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_MOVE) {
                getParent().requestDisallowInterceptTouchEvent(true);
                int ci = (int) (e.getX() / (getWidth() / (float) COLS));
                int row = (int) (e.getY() / (getHeight() / (float) ROWS));
                ci = Math.max(0, Math.min(COLS - 1, ci));
                row = Math.max(0, Math.min(ROWS - 1, row));
                if (ci != selC || row != selR) {
                    selC = ci;
                    selR = row;
                    invalidate();
                    Oui.tick(this);
                    if (listener != null) listener.on(cell[ci][row]);
                }
                return true;
            }
            return true;
        }
    }

    // ---------- hue (x) / lightness (y) spectrum ----------
    static class Spectrum extends View {
        interface L {
            void on(int color);
        }

        private final float d;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path clip = new Path();
        private final RectF r = new RectF();
        private float hue, light = 0.5f;
        private int cur = 0xFF0000FF;
        private L listener;

        Spectrum(Context c) {
            super(c);
            d = c.getResources().getDisplayMetrics().density;
            if (SPEC == null) {
                int bw = 360, bh = 240;
                int[] px = new int[bw * bh];
                for (int y = 0; y < bh; y++) {
                    float l = 1f - y / (bh - 1f);
                    for (int x = 0; x < bw; x++) px[y * bw + x] = hsl(x, 1f, l);
                }
                SPEC = Bitmap.createBitmap(px, bw, bh, Bitmap.Config.ARGB_8888);
            }
        }

        void setListener(L l) {
            listener = l;
        }

        void setColor(int color) {
            float[] x = toHsl(color);
            hue = x[0];
            light = x[2];
            cur = color | 0xFF000000;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            r.set(0, 0, w, h);
            clip.reset();
            clip.addRoundRect(r, 14 * d, 14 * d, Path.Direction.CW);
            c.save();
            c.clipPath(clip);
            c.drawBitmap(SPEC, null, r, p);
            c.restore();
            float cx = Math.min(w, Math.max(0f, hue / 360f * w));
            float cy = Math.min(h, Math.max(0f, (1f - light) * h));
            p.setStyle(Paint.Style.FILL);
            p.setColor(cur);
            c.drawCircle(cx, cy, 10 * d, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(3f * d);
            p.setColor(0xFFFFFFFF);
            c.drawCircle(cx, cy, 11.5f * d, p);
            p.setStrokeWidth(1f * d);
            p.setColor(0x55000000);
            c.drawCircle(cx, cy, 13.5f * d, p);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_MOVE) {
                getParent().requestDisallowInterceptTouchEvent(true);
                float fx = Math.max(0f, Math.min(1f, e.getX() / getWidth()));
                float fy = Math.max(0f, Math.min(1f, e.getY() / getHeight()));
                hue = Math.min(359f, fx * 360f);
                light = 1f - fy;
                cur = hsl(hue, 1f, light);
                invalidate();
                if (listener != null) listener.on(cur);
                return true;
            }
            return true;
        }
    }

    // ---------- dialog ----------
    private final Activity a;
    private final float d;
    private final int orig;
    private final int[] recents;
    private final Callback cb;
    private int cur;
    private Dialog dlg;
    private SwatchGrid grid;
    private Spectrum spec;
    private GradientDrawable newBg;
    private EditText hex, red, green, blue;
    private TextView tabSw, tabSp;
    private boolean updating;

    private Picker(Activity a, int initial, int[] recents, Callback cb) {
        this.a = a;
        this.d = a.getResources().getDisplayMetrics().density;
        this.orig = initial | 0xFF000000;
        this.cur = this.orig;
        this.recents = recents;
        this.cb = cb;
    }

    static void show(Activity a, int initial, int[] recents, Callback cb) {
        new Picker(a, initial, recents, cb).open();
    }

    private int dp(float v) {
        return (int) (v * d + 0.5f);
    }

    private TextView text(String s, float size, int color) {
        TextView t = new TextView(a);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private TextView tab(String s) {
        TextView t = text(s, 17, GRAY);
        t.setGravity(Gravity.CENTER);
        t.setClickable(true);
        return t;
    }

    private void showTab(boolean swatches) {
        grid.setVisibility(swatches ? View.VISIBLE : View.GONE);
        spec.setVisibility(swatches ? View.GONE : View.VISIBLE);
        GradientDrawable on = new GradientDrawable();
        on.setColor(PILL);
        on.setCornerRadius(dp(22));
        tabSw.setBackground(swatches ? on : null);
        tabSp.setBackground(swatches ? null : on);
        tabSw.setTextColor(swatches ? Color.WHITE : GRAY);
        tabSp.setTextColor(swatches ? GRAY : Color.WHITE);
        tabSw.setTypeface(null, swatches ? Typeface.BOLD : Typeface.NORMAL);
        tabSp.setTypeface(null, swatches ? Typeface.NORMAL : Typeface.BOLD);
    }

    private EditText field(boolean hexField) {
        EditText e = new EditText(a);
        e.setBackground(null);
        e.setTextColor(Color.WHITE);
        e.setTextSize(17);
        e.setGravity(Gravity.CENTER);
        e.setSingleLine(true);
        e.setPadding(0, dp(4), 0, dp(4));
        if (hexField) {
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                    | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
            e.setFilters(new InputFilter[]{new InputFilter.LengthFilter(7)});
        } else {
            e.setInputType(InputType.TYPE_CLASS_NUMBER);
            e.setFilters(new InputFilter[]{new InputFilter.LengthFilter(3)});
        }
        return e;
    }

    private LinearLayout column(String label, EditText value, float weight) {
        LinearLayout c = new LinearLayout(a);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView l = text(label, 13, GRAY);
        l.setGravity(Gravity.CENTER);
        c.addView(l);
        c.addView(value, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        c.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, weight));
        return c;
    }

    private void setColor(int c, View source) {
        cur = c | 0xFF000000;
        newBg.setColor(cur);
        updating = true;
        if (source != hex) hex.setText(String.format("#%06X", cur & 0xFFFFFF));
        if (source != red) red.setText(String.valueOf((cur >> 16) & 255));
        if (source != green) green.setText(String.valueOf((cur >> 8) & 255));
        if (source != blue) blue.setText(String.valueOf(cur & 255));
        updating = false;
        if (source != grid) grid.select(cur);
        if (source != spec) spec.setColor(cur);
    }

    private int num(EditText e) {
        try {
            int v = Integer.parseInt(e.getText().toString().trim());
            return Math.max(0, Math.min(255, v));
        } catch (Exception ex) {
            return 0;
        }
    }

    private void open() {
        dlg = new Dialog(a);
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);
        int sw = a.getResources().getDisplayMetrics().widthPixels;
        int sh = a.getResources().getDisplayMetrics().heightPixels;
        int dialogW = (int) (sw * 0.94f);
        int pad = dp(20);

        LinearLayout card = new LinearLayout(a);
        card.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable cg = new GradientDrawable();
        cg.setColor(CARD);
        cg.setCornerRadius(dp(30));
        card.setBackground(cg);
        card.setPadding(pad, dp(16), pad, dp(6));

        // tabs
        LinearLayout tabs = new LinearLayout(a);
        tabSw = tab("Swatches");
        tabSp = tab("Spectrum");
        tabs.addView(tabSw, new LinearLayout.LayoutParams(0, dp(44), 1f));
        tabs.addView(tabSp, new LinearLayout.LayoutParams(0, dp(44), 1f));
        card.addView(tabs, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        // grid / spectrum
        int gw = dialogW - 2 * pad;
        int gh = (int) (gw * 1.147f);
        int maxH = (int) (sh * 0.40f);
        if (gh > maxH) gh = maxH;
        FrameLayout frame = new FrameLayout(a);
        grid = new SwatchGrid(a);
        spec = new Spectrum(a);
        frame.addView(grid, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        frame.addView(spec, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, gh);
        flp.topMargin = dp(14);
        card.addView(frame, flp);

        // preview + hex / rgb
        LinearLayout info = new LinearLayout(a);
        info.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout prev = new LinearLayout(a);
        float rr = dp(14);
        View oldSw = new View(a);
        GradientDrawable og = new GradientDrawable();
        og.setColor(orig);
        og.setCornerRadii(new float[]{rr, rr, 0, 0, 0, 0, rr, rr});
        oldSw.setBackground(og);
        View newSw = new View(a);
        newBg = new GradientDrawable();
        newBg.setColor(cur);
        newBg.setCornerRadii(new float[]{0, 0, rr, rr, rr, rr, 0, 0});
        newSw.setBackground(newBg);
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(dp(44), dp(56));
        prev.addView(oldSw, pl);
        LinearLayout.LayoutParams pr = new LinearLayout.LayoutParams(dp(44), dp(56));
        pr.leftMargin = dp(2);
        prev.addView(newSw, pr);
        info.addView(prev, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        hex = field(true);
        red = field(false);
        green = field(false);
        blue = field(false);
        LinearLayout cols = new LinearLayout(a);
        cols.addView(column("Hex", hex, 1.7f));
        cols.addView(column("Red", red, 1f));
        cols.addView(column("Green", green, 1f));
        cols.addView(column("Blue", blue, 1f));
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        cl.leftMargin = dp(10);
        info.addView(cols, cl);
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        ilp.topMargin = dp(16);
        card.addView(info, ilp);

        // recently used
        TextView rl = text("Recently used colors", 17, Color.WHITE);
        rl.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rlp.topMargin = dp(16);
        card.addView(rl, rlp);
        LinearLayout recent = new LinearLayout(a);
        for (int i = 0; i < recents.length && i < 6; i++) {
            final int rc = recents[i];
            View dot = new View(a);
            GradientDrawable dg = new GradientDrawable();
            dg.setShape(GradientDrawable.OVAL);
            dg.setColor(rc);
            dg.setStroke(dp(1), 0x66FFFFFF);
            dot.setBackground(dg);
            dot.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    Oui.tick(v);
                    setColor(rc, null);
                }
            });
            LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(dp(42), dp(42));
            dl.rightMargin = dp(12);
            recent.addView(dot, dl);
        }
        LinearLayout.LayoutParams rcl = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rcl.topMargin = dp(10);
        card.addView(recent, rcl);

        // Cancel | Done
        LinearLayout bar = new LinearLayout(a);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        TextView cancel = barButton("Cancel");
        TextView done = barButton("Done");
        cancel.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Oui.tap(v);
                dlg.dismiss();
            }
        });
        done.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Oui.tap(v);
                dlg.dismiss();
                if (cb != null) cb.onPicked(cur);
            }
        });
        View div = new View(a);
        div.setBackgroundColor(0x44FFFFFF);
        bar.addView(cancel, new LinearLayout.LayoutParams(0, dp(56), 1f));
        bar.addView(div, new LinearLayout.LayoutParams(dp(1), dp(22)));
        bar.addView(done, new LinearLayout.LayoutParams(0, dp(56), 1f));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        blp.topMargin = dp(10);
        card.addView(bar, blp);

        // listeners
        grid.setListener(new SwatchGrid.L() {
            public void on(int color) {
                setColor(color, grid);
            }
        });
        spec.setListener(new Spectrum.L() {
            public void on(int color) {
                setColor(color, spec);
            }
        });
        tabSw.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Oui.tick(v);
                showTab(true);
            }
        });
        tabSp.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Oui.tick(v);
                showTab(false);
            }
        });
        hex.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int af) {}

            public void onTextChanged(CharSequence s, int st, int b, int c) {}

            public void afterTextChanged(Editable e) {
                if (updating) return;
                String t = e.toString().trim();
                if (t.startsWith("#")) t = t.substring(1);
                if (t.length() != 6) return;
                try {
                    setColor((int) Long.parseLong(t, 16), hex);
                } catch (Exception ex) {
                    // ignore partial input
                }
            }
        });
        TextWatcher rgb = new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int af) {}

            public void onTextChanged(CharSequence s, int st, int b, int c) {}

            public void afterTextChanged(Editable e) {
                if (updating) return;
                int col = 0xFF000000 | (num(red) << 16) | (num(green) << 8) | num(blue);
                View src = red.hasFocus() ? red : (green.hasFocus() ? green : blue);
                setColor(col, src);
            }
        };
        red.addTextChangedListener(rgb);
        green.addTextChangedListener(rgb);
        blue.addTextChangedListener(rgb);

        setColor(cur, null);
        showTab(true);

        dlg.setContentView(card);
        Window w = dlg.getWindow();
        w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        w.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
                | WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        w.setLayout(dialogW, WindowManager.LayoutParams.WRAP_CONTENT);
        w.setGravity(Gravity.CENTER);
        dlg.show();
    }

    private TextView barButton(String s) {
        TextView t = text(s, 18, Color.WHITE);
        t.setTypeface(null, Typeface.BOLD);
        t.setGravity(Gravity.CENTER);
        t.setClickable(true);
        return t;
    }
}
