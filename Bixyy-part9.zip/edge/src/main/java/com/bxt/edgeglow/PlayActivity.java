package com.bxt.edgeglow;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

/**
 * Invisible activity behind the "Play edge lighting" app shortcut. Pick it in Samsung Modes and Routines
 * ("Open an app or do an app action") to play the edge lighting with the saved settings, no notification needed.
 */
public class PlayActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        overridePendingTransition(0, 0);
        play(getApplicationContext(), 0);
        // Leave at once and drop our (empty) task so the app you were in is simply resumed.
        finishAndRemoveTask();
        overridePendingTransition(0, 0);
    }

    // The accessibility service may still be starting when the process was just launched, so retry briefly.
    static void play(final Context app, final int attempt) {
        MainActivity.GlowService s = MainActivity.GlowService.instance;
        if (s != null) {
            s.showGlow(0);
            return;
        }
        if (attempt >= 20) {
            Toast.makeText(app, "Edge Lighting: turn on its accessibility service first", Toast.LENGTH_LONG).show();
            return;
        }
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            public void run() {
                play(app, attempt + 1);
            }
        }, 150);
    }
}
