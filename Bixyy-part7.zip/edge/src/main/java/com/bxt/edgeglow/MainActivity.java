package com.bxt.edgeglow;

import android.accessibilityservice.AccessibilityService;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Settings;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.view.Choreographer;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;

public class MainActivity extends Activity {
    static final String PREFS = "cfg";
    static final String[] CKEYS = {"fx", "color_auto", "color_val", "color_two", "color_val2",
            "color_on3", "color_val3", "color_on4", "color_val4",
            "transp", "dur", "repeat", "line_w", "glow_corner", "glow_depth2", "fx_edge"};
    static final int[] SWATCH = {0xFF0A84FF, 0xFFFF5A68, 0xFFE02B2B, 0xFFF07A12, 0xFFC1DF62,
            0xFF2ECC71, 0xFF00BFBF, 0xFF8AB4D6, 0xFF5B5BFF, 0xFFC27373, 0xFF9B2FAE};
    static final int GRAY = 0xFFB0B0B0;

    SharedPreferences sp;
    Map<String, Object> snap = new HashMap<String, Object>();
    FxView preview;
    LinearLayout content;
    TextView status;
    TextView[] tabs = new TextView[4];
    FxView[] cells;
    TextView[] labels;
    int tab = 0;
    LinearLayout sheet;
    ScrollView sv;

    @Override
    protected void onCreate(Bundle b) {
        setTheme(android.R.style.Theme_Material_NoActionBar);
        super.onCreate(b);
        sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        snap.putAll(sp.getAll());
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        }
        Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS | WindowManager.LayoutParams.FLAG_FULLSCREEN);
        w.setStatusBarColor(Color.TRANSPARENT);
        w.setNavigationBarColor(Color.TRANSPARENT);
        w.getDecorView().setBackgroundColor(Color.BLACK);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams wl = w.getAttributes();
            wl.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            w.setAttributes(wl);
        }
        if (Build.VERSION.SDK_INT >= 29) w.setNavigationBarContrastEnforced(false);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        // Full-screen live preview: the whole app screen shows the selected effect.
        preview = new FxView(this, sp, false, null);

        // Bottom sheet, like the system Edge lighting editor.
        sheet = new LinearLayout(this);
        sheet.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable sg = new GradientDrawable();
        sg.setColor(0xFF252525);
        float rr = dp(28);
        sg.setCornerRadii(new float[]{rr, rr, rr, rr, 0, 0, 0, 0});
        sheet.setBackground(sg);
        sheet.setPadding(dp(12), dp(14), dp(12), dp(20));

        LinearLayout tabBar = new LinearLayout(this);
        tabBar.setOrientation(LinearLayout.HORIZONTAL);
        String[] names = {"Effect", "Color", "Advanced", "More"};
        for (int i = 0; i < 4; i++) {
            TextView t = tv(names[i], 15, 0xFFDDDDDD);
            t.setGravity(Gravity.CENTER);
            t.setPadding(dp(6), dp(10), dp(6), dp(10));
            final int idx = i;
            t.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    Oui.tick(v);
                    selectTab(idx);
                }
            });
            tabBar.addView(t, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            tabs[i] = t;
        }
        sheet.addView(tabBar);

        sv = new ScrollView(this);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(4), dp(14), dp(4), dp(8));
        sv.addView(content);
        sheet.addView(sv, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        Button cancel = flatButton("Cancel", new View.OnClickListener() {
            public void onClick(View v) {
                revert();
                finish();
            }
        });
        Button done = flatButton("Done", new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });
        View div = new View(this);
        div.setBackgroundColor(0x33FFFFFF);
        bar.addView(cancel, new LinearLayout.LayoutParams(0, dp(52), 1f));
        bar.addView(div, new LinearLayout.LayoutParams(dp(1), dp(22)));
        bar.addView(done, new LinearLayout.LayoutParams(0, dp(52), 1f));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        blp.topMargin = dp(4);
        sheet.addView(bar, blp);

        root.addView(sheet, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM));
        // The effect sits on top of the sheet (it never takes touches), like the real edge lighting.
        root.addView(preview, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            public android.view.WindowInsets onApplyWindowInsets(View v, android.view.WindowInsets in) {
                sheet.setPadding(dp(12), dp(14), dp(12), Math.max(dp(20), in.getSystemWindowInsetBottom()));
                return in;
            }
        });
        setContentView(root);
        hideBars();
        selectTab(0);
        root.requestApplyInsets();
    }

    void hideBars() {
        Window w = getWindow();
        if (Build.VERSION.SDK_INT >= 30) {
            w.setDecorFitsSystemWindows(false);
            android.view.WindowInsetsController ic = w.getInsetsController();
            if (ic != null) {
                ic.hide(android.view.WindowInsets.Type.statusBars() | android.view.WindowInsets.Type.navigationBars());
                ic.setSystemBarsBehavior(android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideBars();
    }

    Button flatButton(String text, View.OnClickListener l) {
        Button bt = new Button(this);
        bt.setText(text);
        bt.setAllCaps(false);
        bt.setTextSize(18);
        bt.setTypeface(null, Typeface.BOLD);
        bt.setTextColor(Color.WHITE);
        bt.setBackgroundColor(Color.TRANSPARENT);
        final View.OnClickListener inner = l;
        bt.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Oui.tap(v);
                inner.onClick(v);
            }
        });
        return bt;
    }

    void revert() {
        SharedPreferences.Editor e = sp.edit();
        for (String k : CKEYS) {
            Object v = snap.get(k);
            if (v == null) e.remove(k);
            else if (v instanceof Boolean) e.putBoolean(k, (Boolean) v);
            else if (v instanceof Integer) e.putInt(k, (Integer) v);
            else if (v instanceof String) e.putString(k, (String) v);
        }
        e.apply();
    }

    void selectTab(int idx) {
        tab = idx;
        for (int i = 0; i < 4; i++) {
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(dp(22));
            g.setColor(i == idx ? 0xFF3D3D3D : Color.TRANSPARENT);
            tabs[i].setBackground(g);
            tabs[i].setTextColor(i == idx ? Color.WHITE : GRAY);
            tabs[i].setTypeface(null, i == idx ? Typeface.BOLD : Typeface.NORMAL);
        }
        FrameLayout.LayoutParams sl = (FrameLayout.LayoutParams) sheet.getLayoutParams();
        sl.height = idx == 0 ? FrameLayout.LayoutParams.WRAP_CONTENT
                : (int) (getResources().getDisplayMetrics().heightPixels * 0.58f);
        sheet.setLayoutParams(sl);
        LinearLayout.LayoutParams vl = (LinearLayout.LayoutParams) sv.getLayoutParams();
        if (idx == 0) {
            vl.height = LinearLayout.LayoutParams.WRAP_CONTENT;
            vl.weight = 0f;
        } else {
            vl.height = 0;
            vl.weight = 1f;
        }
        sv.setLayoutParams(vl);
        content.removeAllViews();
        status = null;
        if (idx == 0) buildEffects();
        else if (idx == 1) buildColor();
        else if (idx == 2) buildAdvanced();
        else buildMore();
        if (preview != null) preview.restart();
    }

    String currentFx() {
        String cur = sp.getString("fx", "basic");
        for (String id : Fx.IDS) if (id.equals(cur)) return cur;
        return "basic";
    }

    // Two rows, scrolling horizontally. Row 1 holds the first half, row 2 the second half.
    void buildEffects() {
        String cur = currentFx();
        int n = Fx.IDS.length;
        cells = new FxView[n];
        labels = new TextView[n];
        int cols = (n + 1) / 2;
        int colW = (getResources().getDisplayMetrics().widthPixels - dp(32)) / 4;
        int tile = Math.min(colW - dp(10), dp(84));
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.setOverScrollMode(View.OVER_SCROLL_NEVER);
        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        for (int r = 0; r < 2; r++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int c = 0; c < cols; c++) {
                int i = r * cols + c;
                if (i >= n) break;
                LinearLayout cell = new LinearLayout(this);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setGravity(Gravity.CENTER_HORIZONTAL);
                FxView v = new FxView(this, sp, true, Fx.IDS[i]);
                v.setBackground(cellBg(false));
                v.setClipToOutline(true);
                v.ring = Fx.IDS[i].equals(cur);
                TextView l = tv(Fx.NAMES[i], 12, Fx.IDS[i].equals(cur) ? Color.WHITE : GRAY);
                l.setGravity(Gravity.CENTER);
                l.setSingleLine(true);
                l.setPadding(0, dp(6), 0, 0);
                cell.addView(v, new LinearLayout.LayoutParams(tile, tile));
                cell.addView(l);
                final int idx = i;
                cell.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View view) {
                        Oui.tick(view);
                        sp.edit().putString("fx", Fx.IDS[idx]).apply();
                        refreshCells();
                        preview.restart();
                    }
                });
                cells[i] = v;
                labels[i] = l;
                row.addView(cell, new LinearLayout.LayoutParams(colW, LinearLayout.LayoutParams.WRAP_CONTENT));
            }
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            rp.bottomMargin = dp(12);
            grid.addView(row, rp);
        }
        hs.addView(grid);
        content.addView(hs, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
    }

    GradientDrawable cellBg(boolean sel) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.BLACK);
        g.setCornerRadius(dp(18));
        return g;
    }

    void refreshCells() {
        String cur = currentFx();
        for (int i = 0; i < Fx.IDS.length; i++) {
            boolean sel = Fx.IDS[i].equals(cur);
            cells[i].ring = sel;
            cells[i].invalidate();
            labels[i].setTextColor(sel ? Color.WHITE : GRAY);
        }
    }

    void buildColor() {
        boolean auto = sp.getBoolean("color_auto", true);
        LinearLayout modes = ouiCard();
        final LinearLayout rowAuto = ouiRadioRow("Auto (each app's color)");
        final LinearLayout rowColor = ouiRadioRow("Color");
        ((Oui.Radio) rowAuto.getChildAt(0)).setChecked(auto, false);
        ((Oui.Radio) rowColor.getChildAt(0)).setChecked(!auto, false);
        rowAuto.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (sp.getBoolean("color_auto", true)) return;
                Oui.tick(v);
                sp.edit().putBoolean("color_auto", true).apply();
                rebuildColor();
            }
        });
        rowColor.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (!sp.getBoolean("color_auto", true)) return;
                Oui.tick(v);
                sp.edit().putBoolean("color_auto", false).apply();
                rebuildColor();
            }
        });
        modes.addView(rowAuto);
        modes.addView(ouiDivider());
        modes.addView(rowColor);
        content.addView(modes, cardLp(0));

        LinearLayout c1 = ouiCard();
        swatches(c1, "color_val", 0xFF0A84FF, auto);
        content.addView(c1, cardLp(12));

        content.addView(ouiHeader("Gradient line"));
        extraColor("Color 2", "color_two", "color_val2", 0xFFB14CFF, 0);
        extraColor("Color 3", "color_on3", "color_val3", 0xFF22D3EE, 10);
        extraColor("Color 4", "color_on4", "color_val4", 0xFFFFD60A, 10);

    }

    void extraColor(String title, String onKey, String valKey, int def, int topDp) {
        LinearLayout card = ouiCard();
        card.addView(ouiSwitchRow(title, onKey, false, new Runnable() {
            public void run() {
                content.postDelayed(new Runnable() {
                    public void run() {
                        rebuildColor();
                    }
                }, 230);
            }
        }));
        if (sp.getBoolean(onKey, false)) {
            card.addView(ouiDivider());
            swatches(card, valKey, def, false);
        }
        content.addView(card, cardLp(topDp));
    }

    // Rebuilds the Color tab but keeps the scroll position.
    void rebuildColor() {
        if (tab != 1) return;
        final int y = sv.getScrollY();
        content.removeAllViews();
        buildColor();
        sv.post(new Runnable() {
            public void run() {
                sv.scrollTo(0, y);
            }
        });
        if (preview != null) preview.restart();
    }

    void swatches(LinearLayout parent, final String key, final int def, boolean dim) {
        final int cur = sp.getInt(key, def);
        boolean preset = false;
        for (int c : SWATCH) if (c == cur) preset = true;
        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        grid.setPadding(dp(10), dp(8), dp(10), dp(8));
        grid.setAlpha(dim ? 0.45f : 1f);
        int n = SWATCH.length + 1;
        LinearLayout row = null;
        for (int i = 0; i < n; i++) {
            if (i % 6 == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                grid.addView(row);
            }
            LinearLayout cell = new LinearLayout(this);
            cell.setGravity(Gravity.CENTER);
            View sw = new View(this);
            GradientDrawable gd = new GradientDrawable();
            gd.setShape(GradientDrawable.OVAL);
            if (i < SWATCH.length) {
                gd.setColor(SWATCH[i]);
                if (SWATCH[i] == cur) gd.setStroke(dp(3), Color.WHITE);
            } else {
                gd.setGradientType(GradientDrawable.SWEEP_GRADIENT);
                gd.setColors(new int[]{0xFFFF3B30, 0xFFFFD60A, 0xFF34C759, 0xFF22D3EE,
                        0xFF0A84FF, 0xFFB14CFF, 0xFFFF3B30});
                if (!preset) gd.setStroke(dp(3), Color.WHITE);
            }
            sw.setBackground(gd);
            final int idx = i;
            sw.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    Oui.tick(v);
                    if (idx < SWATCH.length) {
                        SharedPreferences.Editor e = sp.edit().putInt(key, SWATCH[idx]);
                        if ("color_val".equals(key)) e.putBoolean("color_auto", false);
                        e.apply();
                        rebuildColor();
                    } else {
                        openPicker(key, def);
                    }
                }
            });
            cell.addView(sw, new LinearLayout.LayoutParams(dp(44), dp(44)));
            row.addView(cell, new LinearLayout.LayoutParams(0, dp(58), 1f));
        }
        parent.addView(grid);
    }

    void openPicker(final String key, int def) {
        Picker.show(this, sp.getInt(key, def), recentColors(), new Picker.Callback() {
            public void onPicked(int color) {
                SharedPreferences.Editor e = sp.edit().putInt(key, color | 0xFF000000);
                if ("color_val".equals(key)) e.putBoolean("color_auto", false);
                e.apply();
                addRecent(color | 0xFF000000);
                rebuildColor();
            }
        });
    }

    int[] recentColors() {
        String s = sp.getString("recent_colors", "");
        if (s.length() == 0) return new int[]{SWATCH[2], SWATCH[1], SWATCH[0], SWATCH[8], SWATCH[10]};
        String[] parts = s.split(",");
        int[] r = new int[parts.length];
        for (int i = 0; i < parts.length; i++) {
            try {
                r[i] = (int) Long.parseLong(parts[i], 16) | 0xFF000000;
            } catch (Exception e) {
                r[i] = SWATCH[0];
            }
        }
        return r;
    }

    void addRecent(int color) {
        int[] old = recentColors();
        StringBuilder sb = new StringBuilder(String.format("%06X", color & 0xFFFFFF));
        int count = 1;
        for (int c : old) {
            if (count >= 6) break;
            if ((c & 0xFFFFFF) == (color & 0xFFFFFF)) continue;
            sb.append(',').append(String.format("%06X", c & 0xFFFFFF));
            count++;
        }
        sp.edit().putString("recent_colors", sb.toString()).apply();
    }

    void buildAdvanced() {
        LinearLayout main = ouiCard();
        main.addView(sliderBlock("Transparency", "Low", "High", "transp", 0, 100, null));
        main.addView(ouiDivider());
        main.addView(sliderBlock("Duration", "Short", "Long", "dur", 20, 100, null, new Runnable() {
            public void run() {
                updateTotal();
            }
        }));
        main.addView(ouiDivider());
        main.addView(repeatBlock());
        content.addView(main, cardLp(0));

        content.addView(ouiHeader("Fine tuning"));
        LinearLayout fine = ouiCard();
        fine.addView(sliderBlock("Line thickness", null, null, "line_w", 4, 14, " dp"));
        fine.addView(ouiDivider());
        fine.addView(sliderBlock("Screen corner radius", null, null, "glow_corner", 36, 80, " dp"));
        fine.addView(ouiDivider());
        fine.addView(sliderBlock("Soft glow depth", null, null, "glow_depth2", 10, 40, " dp"));
        content.addView(fine, cardLp(0));

        LinearLayout edge = ouiCard();
        edge.addView(ouiSwitchRow("Edge line under Bubble and Heart", "fx_edge", true, new Runnable() {
            public void run() {
                if (preview != null) preview.restart();
            }
        }));
        content.addView(edge, cardLp(12));
    }

    TextView totalCap;

    void updateTotal() {
        if (totalCap == null) return;
        totalCap.setText("Total time: " + String.format("%.1f", FxP.totalMs(sp) / 1000f) + " s");
    }

    // "Repeat" = how many times the effect plays in a row (1-10); Duration sets the length of each pass.
    LinearLayout repeatBlock() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(14), dp(20), dp(10));
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = tv("Repeat", 17, Oui.TEXT);
        t.setTypeface(null, Typeface.BOLD);
        head.addView(t, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        final TextView val = tv(FxP.repeats(sp) + "x", 15, GRAY);
        head.addView(val);
        box.addView(head);
        Oui.Slider s = new Oui.Slider(this);
        s.setRange(9, FxP.repeats(sp) - 1);
        s.setListener(new Oui.Slider.Listener() {
            public void onChanged(int value, boolean fromUser) {
                sp.edit().putInt("repeat", value + 1).apply();
                val.setText((value + 1) + "x");
                updateTotal();
            }

            public void onStop() {
                if (preview != null) preview.restart();
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(6);
        box.addView(s, lp);
        totalCap = tv("", 13, GRAY);
        box.addView(totalCap);
        updateTotal();
        return box;
    }

    // Title (+ optional value on the right or Low/High captions) with a One UI slider below.
    LinearLayout sliderBlock(String title, String low, String high, final String key, int def, int max,
                             final String suffix) {
        return sliderBlock(title, low, high, key, def, max, suffix, null);
    }

    LinearLayout sliderBlock(String title, String low, String high, final String key, int def, int max,
                             final String suffix, final Runnable changed) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(14), dp(20), dp(6));
        int start = Math.max(0, Math.min(max, sp.getInt(key, def)));

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = tv(title, 17, Oui.TEXT);
        t.setTypeface(null, Typeface.BOLD);
        head.addView(t, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        final TextView val = tv(start + (suffix == null ? "" : suffix), 15, GRAY);
        if (suffix != null) head.addView(val);
        box.addView(head);

        if (low != null) {
            LinearLayout caps = new LinearLayout(this);
            TextView a = tv(low, 13, GRAY);
            TextView b = tv(high, 13, GRAY);
            b.setGravity(Gravity.END);
            caps.addView(a, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            caps.addView(b, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            box.addView(caps);
        }

        Oui.Slider s = new Oui.Slider(this);
        s.setRange(max, start);
        s.setListener(new Oui.Slider.Listener() {
            public void onChanged(int value, boolean fromUser) {
                sp.edit().putInt(key, value).apply();
                if (suffix != null) val.setText(value + suffix);
                if (changed != null) changed.run();
            }

            public void onStop() {
                if (preview != null) preview.restart();
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(6);
        box.addView(s, lp);
        return box;
    }




    void buildMore() {
        LinearLayout actions = ouiCard();
        actions.setPadding(dp(8), dp(8), dp(8), dp(8));
        addAction(actions, "1) Open accessibility settings", new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        });
        addAction(actions, "2) Grant notification access", new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
            }
        });
        addAction(actions, "3) Battery: set to Unrestricted", new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            }
        });
        addAction(actions, "App info (Allow restricted settings)", new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + getPackageName())));
            }
        });
        content.addView(actions, cardLp(0));

        LinearLayout keep = ouiCard();
        keep.addView(ouiSwitchRow("Keep running in background (shows a small notification)", "keepalive", true,
                new Runnable() {
                    public void run() {
                        syncKeep();
                    }
                }));
        content.addView(keep, cardLp(12));

        content.addView(ouiHeader("Notifications"));
        LinearLayout notif = ouiCard();
        notif.addView(ouiSwitchRow("Glow on notifications", "notif_on", true, null));
        notif.addView(ouiDivider());
        notif.addView(ouiSwitchRow("Skip silent notifications", "notif_skip_silent", true, null));
        notif.addView(ouiDivider());
        notif.addView(ouiSwitchRow("Skip when Do Not Disturb is on", "notif_skip_dnd", true, null));
        content.addView(notif, cardLp(0));

        LinearLayout apps = ouiCard();
        final LinearLayout rowAll = ouiRadioRow("All apps");
        final LinearLayout rowSel = ouiRadioRow("Selected apps only");
        final Oui.Radio rAll = (Oui.Radio) rowAll.getChildAt(0);
        final Oui.Radio rSel = (Oui.Radio) rowSel.getChildAt(0);
        boolean all = !"selected".equals(sp.getString("notif_mode", "all"));
        rAll.setChecked(all, false);
        rSel.setChecked(!all, false);
        rowAll.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (rAll.isChecked()) return;
                Oui.tick(v);
                rAll.setChecked(true, true);
                rSel.setChecked(false, true);
                sp.edit().putString("notif_mode", "all").apply();
            }
        });
        rowSel.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (rSel.isChecked()) return;
                Oui.tick(v);
                rSel.setChecked(true, true);
                rAll.setChecked(false, true);
                sp.edit().putString("notif_mode", "selected").apply();
            }
        });
        apps.addView(rowAll);
        apps.addView(ouiDivider());
        apps.addView(rowSel);
        LinearLayout choose = new LinearLayout(this);
        choose.setPadding(dp(8), dp(4), dp(8), dp(8));
        addAction(choose, "Choose apps...", new View.OnClickListener() {
            public void onClick(View v) {
                showAppPicker();
            }
        });
        apps.addView(choose, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        content.addView(apps, cardLp(12));
    }

    // ---- One UI building blocks ----
    LinearLayout ouiCard() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = new GradientDrawable();
        g.setColor(Oui.CARD);
        g.setCornerRadius(dp(26));
        c.setBackground(g);
        c.setClipToOutline(true);
        return c;
    }

    LinearLayout.LayoutParams cardLp(int topDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(topDp);
        return lp;
    }

    TextView ouiHeader(String text) {
        TextView t = tv(text, 13, 0xFFA0A0A6);
        t.setPadding(dp(22), dp(22), dp(22), dp(8));
        return t;
    }

    View ouiDivider() {
        View v = new View(this);
        v.setBackgroundColor(Oui.DIVIDER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 1);
        lp.leftMargin = dp(20);
        lp.rightMargin = dp(20);
        v.setLayoutParams(lp);
        return v;
    }

    LinearLayout ouiRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setMinimumHeight(dp(56));
        row.setPadding(dp(20), dp(8), dp(20), dp(8));
        StateListDrawable sl = new StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_pressed}, new ColorDrawable(0x22FFFFFF));
        sl.addState(new int[]{}, new ColorDrawable(Color.TRANSPARENT));
        row.setBackground(sl);
        row.setClickable(true);
        return row;
    }

    LinearLayout ouiSwitchRow(String text, final String key, boolean def, final Runnable after) {
        LinearLayout row = ouiRow();
        TextView t = tv(text, 17, Oui.TEXT);
        row.addView(t, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        final Oui.Switch sw = new Oui.Switch(this);
        sw.setChecked(sp.getBoolean(key, def));
        sw.setListener(new Oui.Switch.Listener() {
            public void onChanged(boolean on) {
                sp.edit().putBoolean(key, on).apply();
                if (after != null) after.run();
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.leftMargin = dp(12);
        row.addView(sw, lp);
        row.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                sw.toggle();
            }
        });
        return row;
    }

    /** Radio on the left, text on the right (child 0 is the Oui.Radio). */
    LinearLayout ouiRadioRow(String text) {
        LinearLayout row = ouiRow();
        row.setPadding(dp(14), dp(8), dp(20), dp(8));
        row.addView(new Oui.Radio(this));
        TextView t = tv(text, 17, Oui.TEXT);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.leftMargin = dp(10);
        row.addView(t, lp);
        return row;
    }

    TextView ouiButton(String text, final View.OnClickListener l) {
        TextView b = new TextView(this);
        b.setText(text);
        b.setTextSize(15);
        b.setTextColor(Color.WHITE);
        b.setTypeface(null, Typeface.BOLD);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(16), 0, dp(16), 0);
        GradientDrawable n = new GradientDrawable();
        n.setColor(Oui.BTN);
        n.setCornerRadius(dp(26));
        GradientDrawable pr = new GradientDrawable();
        pr.setColor(Oui.BTN_PRESSED);
        pr.setCornerRadius(dp(26));
        StateListDrawable sl = new StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_pressed}, pr);
        sl.addState(new int[]{}, n);
        b.setBackground(sl);
        b.setClickable(true);
        b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Oui.tap(v);
                l.onClick(v);
            }
        });
        return b;
    }

    void addAction(LinearLayout parent, String text, View.OnClickListener l) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(48));
        lp.topMargin = dp(3);
        lp.bottomMargin = dp(3);
        if (parent.getOrientation() == LinearLayout.HORIZONTAL) {
            // used inside a plain LinearLayout container: make it fill the width
            parent.setOrientation(LinearLayout.VERTICAL);
        }
        parent.addView(ouiButton(text, l), lp);
    }

    void refreshStatus() {
        if (status == null) return;
        status.setText("Accessibility service: " + (isServiceOn() ? "ON" : "OFF - enable \"Edge Lighting\"")
                + "\nOverlay service running: " + (GlowService.instance != null ? "YES" : "NO")
                + "\nNotification access: " + (notifAccessOn() ? "ON" : "OFF - enable \"Edge Lighting\"")
                + "\nKeep-alive service: " + (KeepAlive.running ? "running" : "not running")
                + "\nLast notification: " + sp.getString("last_event", "none yet")
                + "\nGlow log:\n" + sp.getString("glow_log", "none yet"));
    }

    @Override
    protected void onResume() {
        super.onResume();
        syncKeep();
        refreshStatus();
        if (preview != null) preview.restart();
    }

    View.OnClickListener delayedTest(final int sec) {
        return new View.OnClickListener() {
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Go to the home screen now (" + sec + " s)",
                        Toast.LENGTH_LONG).show();
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    public void run() {
                        GlowService s = GlowService.instance;
                        if (s != null) s.showGlow(0);
                    }
                }, sec * 1000L);
            }
        };
    }

    void syncKeep() {
        try {
            Intent i = new Intent(this, KeepAlive.class);
            if (sp.getBoolean("keepalive", true)) {
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
                else startService(i);
            } else {
                stopService(i);
            }
        } catch (Throwable t) {}
    }

    boolean isServiceOn() {
        String s = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (s == null) return false;
        ComponentName cn = new ComponentName(this, GlowService.class);
        return s.contains(cn.flattenToString()) || s.contains(cn.flattenToShortString());
    }

    boolean notifAccessOn() {
        String s = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        return s != null && s.contains(getPackageName());
    }

    TextView tv(String text, float size, int color) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }



    void showAppPicker() {
        PackageManager pm = getPackageManager();
        Intent li = new Intent(Intent.ACTION_MAIN);
        li.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> ris = pm.queryIntentActivities(li, 0);
        List<String[]> apps = new ArrayList<String[]>();
        Set<String> seen = new HashSet<String>();
        for (ResolveInfo ri : ris) {
            String pkg = ri.activityInfo.packageName;
            if (seen.add(pkg)) apps.add(new String[]{ri.loadLabel(pm).toString(), pkg});
        }
        Collections.sort(apps, new Comparator<String[]>() {
            public int compare(String[] a, String[] b) {
                return a[0].compareToIgnoreCase(b[0]);
            }
        });
        final Set<String> sel = new HashSet<String>(sp.getStringSet("notif_apps", new HashSet<String>()));
        final String[] pkgs = new String[apps.size()];
        String[] names = new String[apps.size()];
        boolean[] checked = new boolean[apps.size()];
        for (int i = 0; i < apps.size(); i++) {
            names[i] = apps.get(i)[0];
            pkgs[i] = apps.get(i)[1];
            checked[i] = sel.contains(pkgs[i]);
        }
        new AlertDialog.Builder(this)
                .setTitle("Apps that show the glow")
                .setMultiChoiceItems(names, checked, new DialogInterface.OnMultiChoiceClickListener() {
                    public void onClick(DialogInterface d, int which, boolean on) {
                        if (on) sel.add(pkgs[which]);
                        else sel.remove(pkgs[which]);
                    }
                })
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        sp.edit().putStringSet("notif_apps", new HashSet<String>(sel)).apply();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    Button button(String text, View.OnClickListener l) {
        Button bt = new Button(this);
        bt.setText(text);
        bt.setAllCaps(false);
        final View.OnClickListener inner = l;
        bt.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Oui.tap(v);
                inner.onClick(v);
            }
        });
        return bt;
    }



    public static class KeepAlive extends Service {
        static boolean running;

        @Override
        public IBinder onBind(Intent i) {
            return null;
        }

        @Override
        public int onStartCommand(Intent i, int flags, int startId) {
            try {
                NotificationManager nm = getSystemService(NotificationManager.class);
                Notification.Builder nb;
                if (Build.VERSION.SDK_INT >= 26) {
                    nm.createNotificationChannel(new NotificationChannel("keep", "Edge Lighting running",
                            NotificationManager.IMPORTANCE_MIN));
                    nb = new Notification.Builder(this, "keep");
                } else {
                    nb = new Notification.Builder(this);
                }
                nb.setSmallIcon(android.R.drawable.ic_dialog_info)
                        .setContentTitle("Edge Lighting is running")
                        .setOngoing(true);
                if (Build.VERSION.SDK_INT >= 34) {
                    startForeground(1, nb.build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
                } else {
                    startForeground(1, nb.build());
                }
                running = true;
            } catch (Throwable t) {
                running = false;
                stopSelf();
            }
            return START_STICKY;
        }

        @Override
        public void onDestroy() {
            running = false;
            super.onDestroy();
        }
    }

    public static class NotifService extends NotificationListenerService {
        long last;

        @Override
        public void onNotificationPosted(StatusBarNotification sbn) {
            SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
            String pkg = sbn.getPackageName();
            String result;
            try {
                String why = decide(sp, sbn, pkg);
                if (why != null) {
                    result = "skipped (" + why + ")";
                } else {
                    GlowService s = GlowService.instance;
                    if (s == null) {
                        result = "overlay service not running";
                    } else {
                        int color = sp.getBoolean("color_auto", true) ? dominant(pkg) : 0;
                        s.showGlow(color);
                        result = "glow shown";
                    }
                }
            } catch (Throwable t) {
                result = "error: " + t.getClass().getSimpleName();
            }
            String time = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
            sp.edit().putString("last_event", time + "  " + pkg + "  " + result).apply();
        }

        String decide(SharedPreferences sp, StatusBarNotification sbn, String pkg) {
            if (!sp.getBoolean("notif_on", true)) return "disabled";
            if (pkg.equals(getPackageName())) return "own app";
            Notification n = sbn.getNotification();
            if (sbn.isOngoing() || (n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) return "ongoing or group";
            if (sp.getBoolean("notif_skip_silent", true)) {
                RankingMap rm = getCurrentRanking();
                Ranking r = new Ranking();
                if (rm != null && rm.getRanking(sbn.getKey(), r)
                        && r.getImportance() < NotificationManager.IMPORTANCE_DEFAULT) return "silent";
            }
            if (sp.getBoolean("notif_skip_dnd", true) && getCurrentInterruptionFilter() > 1) {
                return "do not disturb";
            }
            if ("selected".equals(sp.getString("notif_mode", "all"))) {
                Set<String> allowed = sp.getStringSet("notif_apps", new HashSet<String>());
                if (!allowed.contains(pkg)) return "app not selected";
            }
            long now = SystemClock.elapsedRealtime();
            if (now - last < 1500) return "too soon after the previous one";
            last = now;
            return null;
        }

        int dominant(String pkg) {
            try {
                Drawable d = getPackageManager().getApplicationIcon(pkg);
                Bitmap b = Bitmap.createBitmap(32, 32, Bitmap.Config.ARGB_8888);
                Canvas c = new Canvas(b);
                d.setBounds(0, 0, 32, 32);
                d.draw(c);
                float[] score = new float[12];
                float[] hsv = new float[3];
                for (int x = 0; x < 32; x++) {
                    for (int y = 0; y < 32; y++) {
                        int p = b.getPixel(x, y);
                        if (Color.alpha(p) < 200) continue;
                        Color.colorToHSV(p, hsv);
                        score[Math.min(11, (int) (hsv[0] / 30f))] += hsv[1] * hsv[2];
                    }
                }
                int best = 0;
                for (int i = 1; i < 12; i++) if (score[i] > score[best]) best = i;
                if (score[best] < 12f) return 0;
                return Color.HSVToColor(new float[]{best * 30f + 15f, 0.85f, 1f});
            } catch (Throwable t) {
                return 0;
            }
        }
    }

    public static class GlowService extends AccessibilityService {
        static GlowService instance;
        WindowManager wm;
        GlowView glow;
        SharedPreferences sp;

        @Override
        protected void onServiceConnected() {
            super.onServiceConnected();
            instance = this;
            wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        }

        @Override
        public void onAccessibilityEvent(AccessibilityEvent e) {}

        @Override
        public void onInterrupt() {}

        @Override
        public boolean onUnbind(Intent i) {
            hideGlow();
            if (instance == this) instance = null;
            return super.onUnbind(i);
        }

        @Override
        public void onDestroy() {
            hideGlow();
            if (instance == this) instance = null;
            super.onDestroy();
        }

        void hideGlow() {
            if (glow != null) {
                glow.stop();
                if (wm != null) {
                    try { wm.removeView(glow); } catch (Throwable t) {}
                }
            }
            glow = null;
        }

        void stat(String m) {
            String old = sp.getString("glow_log", "");
            String[] lines = old.isEmpty() ? new String[0] : old.split("\n");
            StringBuilder sb = new StringBuilder();
            for (int i = Math.max(0, lines.length - 7); i < lines.length; i++) sb.append(lines[i]).append("\n");
            sb.append(new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date())).append(" ").append(m);
            sp.edit().putString("glow_log", sb.toString()).apply();
        }

        void showGlow(final int accent) {
            if (Looper.myLooper() != Looper.getMainLooper()) {
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    public void run() {
                        showGlow(accent);
                    }
                });
                return;
            }
            if (wm == null || sp == null) return;
            FxP fp = FxP.load(sp, getResources().getDisplayMetrics().density, accent);
            if ("none".equals(fp.fx)) {
                stat("effect is None");
                return;
            }
            hideGlow();
            ActivityManager.RunningAppProcessInfo ri = new ActivityManager.RunningAppProcessInfo();
            ActivityManager.getMyMemoryState(ri);
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            stat("start " + fp.fx + " imp=" + ri.importance + " interactive=" + pm.isInteractive()
                    + " save=" + pm.isPowerSaveMode() + " doze=" + pm.isDeviceIdleMode());
            final GlowView g = new GlowView(this, fp);
            WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            if (Build.VERSION.SDK_INT >= 28) {
                p.layoutInDisplayCutoutMode =
                        WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            }
            try {
                wm.addView(g, p);
            } catch (Throwable t) {
                stat("addView FAILED: " + t.getClass().getSimpleName() + " " + t.getMessage());
                return;
            }
            glow = g;
            g.play(300, FxP.holdMs(sp), 500, FxP.repeats(sp), new Runnable() {
                public void run() {
                    stat("end " + snap(g));
                    if (glow == g) hideGlow();
                }
            });
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                public void run() {
                    stat("+0.3s " + snap(g));
                }
            }, 300);
        }

        String snap(GlowView g) {
            return "att=" + g.isAttachedToWindow() + " vis=" + g.getWindowVisibility()
                    + " size=" + g.getWidth() + "x" + g.getHeight()
                    + " c=" + g.cTicks + " h=" + g.hTicks + " dc=" + g.drawCalls + " d=" + g.draws;
        }
    }
}

class FxP {
    float d, lineW, corner, depth, alpha;
    boolean edge;
    int color;
    int[] lineColors;
    String fx;

    static int holdMs(SharedPreferences sp) {
        return 300 + sp.getInt("dur", 20) * 25;
    }

    // How many times the whole effect is played in a row (1..10).
    static int repeats(SharedPreferences sp) {
        return Math.max(1, Math.min(10, sp.getInt("repeat", 1)));
    }

    // One pass = fade in 300 ms + hold + fade out 500 ms; total = passes in a row.
    static int totalMs(SharedPreferences sp) {
        return (300 + holdMs(sp) + 500) * repeats(sp);
    }

    static FxP load(SharedPreferences sp, float d, int accent) {
        FxP p = new FxP();
        p.d = d;
        String f = sp.getString("fx", "basic");
        boolean known = false;
        for (String id : Fx.IDS) if (id.equals(f)) known = true;
        p.fx = known ? f : "basic";
        p.lineW = Math.max(1, sp.getInt("line_w", 4)) * d;
        p.corner = sp.getInt("glow_corner", 36) * d;
        p.depth = Math.max(2, sp.getInt("glow_depth2", 10)) * d;
        p.edge = sp.getBoolean("fx_edge", true);
        p.alpha = 1f - 0.8f * sp.getInt("transp", 0) / 100f;
        boolean auto = sp.getBoolean("color_auto", true);
        if (auto) p.color = accent != 0 ? accent : 0xFF0A84FF;
        else p.color = sp.getInt("color_val", 0xFF0A84FF);
        java.util.ArrayList<Integer> cs = new java.util.ArrayList<Integer>();
        cs.add(p.color);
        if (sp.getBoolean("color_two", false)) cs.add(sp.getInt("color_val2", 0xFFB14CFF));
        if (sp.getBoolean("color_on3", false)) cs.add(sp.getInt("color_val3", 0xFF22D3EE));
        if (sp.getBoolean("color_on4", false)) cs.add(sp.getInt("color_val4", 0xFFFFD60A));
        if (cs.size() > 1) {
            int[] arr = new int[cs.size() + 1];
            for (int i = 0; i < cs.size(); i++) arr[i] = cs.get(i);
            arr[cs.size()] = cs.get(0);
            p.lineColors = arr;
        }
        return p;
    }
}

class Fx {
    static final String[] IDS = {"none", "basic", "wave", "bubble", "glow", "heart",
            "shimmer", "pulse", "rotate", "gravity", "eclipse", "eclipselight", "flash", "centerglow"};
    static final String[] NAMES = {"None", "Basic", "Wave", "Bubble", "Glow", "Heart",
            "Shimmer", "Pulse", "Rotate", "Gravity", "Eclipse", "Eclipse light", "Flash", "Center Glow"};
    static final int[] MULTI = {0xFF2F7BFF, 0xFF22D3EE, 0xFF34C759, 0xFFFFD60A, 0xFF2F7BFF};

    static final Paint P = new Paint(Paint.ANTI_ALIAS_FLAG);
    static final RectF R = new RectF();
    static final Matrix M = new Matrix();
    static final Path HP = new Path();
    static final float[] POS = new float[2];

    static SweepGradient SG;
    static int[] SGC;
    static int sgW, sgH;
    static PathMeasure PM;
    static Path PP;
    static int pmW, pmH;
    static float pmI, pmC;

    static float cl(float x) {
        return Math.max(0f, Math.min(1f, x));
    }

    static float ease(float x) {
        x = cl(x);
        return x * x * (3f - 2f * x);
    }

    static int al(int color, float a) {
        int v = (int) (Color.alpha(color) * cl(a));
        return (v << 24) | (color & 0x00FFFFFF);
    }

    static void prep(Paint.Style st, float w) {
        P.reset();
        P.setAntiAlias(true);
        P.setStyle(st);
        P.setStrokeWidth(w);
    }

    static SweepGradient sweep(int w, int h, int[] colors, float angle) {
        if (SG == null || SGC != colors || sgW != w || sgH != h) {
            SG = new SweepGradient(w / 2f, h / 2f, colors, null);
            SGC = colors;
            sgW = w;
            sgH = h;
        }
        M.setRotate(angle, w / 2f, h / 2f);
        SG.setLocalMatrix(M);
        return SG;
    }

    static PathMeasure perim(int w, int h, float inset, float corner) {
        if (PM == null || pmW != w || pmH != h || pmI != inset || pmC != corner) {
            PP = new Path();
            float r = Math.max(0f, corner - inset);
            PP.addRoundRect(new RectF(inset, inset, w - inset, h - inset), r, r, Path.Direction.CW);
            PM = new PathMeasure(PP, false);
            pmW = w;
            pmH = h;
            pmI = inset;
            pmC = corner;
        }
        return PM;
    }

    static void edgeLine(Canvas c, int w, int h, FxP p, float width, float a, float inset, float ang) {
        prep(Paint.Style.STROKE, width);
        if (p.lineColors != null) {
            P.setShader(sweep(w, h, p.lineColors, ang));
            P.setAlpha((int) (255 * cl(a)));
        } else {
            P.setColor(al(p.color, a));
        }
        R.set(inset, inset, w - inset, h - inset);
        float r = Math.max(0f, p.corner - inset);
        c.drawRoundRect(R, r, r, P);
    }

    static void palLine(Canvas c, int w, int h, FxP p, int[] pal, float ang, float a, float width, float inset) {
        prep(Paint.Style.STROKE, width);
        P.setShader(sweep(w, h, pal, ang));
        P.setAlpha((int) (255 * cl(a)));
        R.set(inset, inset, w - inset, h - inset);
        float r = Math.max(0f, p.corner - inset);
        c.drawRoundRect(R, r, r, P);
    }

    static void basic(Canvas c, int w, int h, FxP p, float a, float ang) {
        float inset = p.lineW / 2f + 1f;
        for (int i = 4; i >= 1; i--) {
            edgeLine(c, w, h, p, p.lineW * (1f + i * 0.9f), a * 0.07f, inset, ang);
        }
        edgeLine(c, w, h, p, p.lineW, a, inset, ang);
    }

    static void heart(Canvas c, float cx, float cy, float s) {
        HP.reset();
        HP.moveTo(cx, cy + s * 0.55f);
        HP.cubicTo(cx + s * 1.1f, cy - s * 0.05f, cx + s * 0.55f, cy - s * 0.95f, cx, cy - s * 0.35f);
        HP.cubicTo(cx - s * 0.55f, cy - s * 0.95f, cx - s * 1.1f, cy - s * 0.05f, cx, cy + s * 0.55f);
        HP.close();
        c.drawPath(HP, P);
    }

    static void particles(Canvas c, int w, int h, FxP p, float t, float a, boolean hearts) {
        float inset = p.lineW / 2f + 1f;
        PathMeasure pm = perim(w, h, inset, p.corner);
        float len = pm.getLength();
        float cx = w / 2f, cy = h / 2f, d = p.d;
        Random rnd = new Random(hearts ? 23 : 11);
        int n = hearts ? 16 : 24;
        for (int i = 0; i < n; i++) {
            float s = rnd.nextFloat();
            float delay = rnd.nextFloat() * 0.45f;
            float size = (hearts ? 5f + rnd.nextFloat() * 7f : 2f + rnd.nextFloat() * 4f) * d;
            float dist = (40f + rnd.nextFloat() * 110f) * d;
            float u = (t - delay) / 0.55f;
            if (u < 0f || u > 1f) continue;
            pm.getPosTan(s * len, POS, null);
            float dx = cx - POS[0], dy = cy - POS[1];
            float L = (float) Math.sqrt(dx * dx + dy * dy);
            if (L < 1f) continue;
            dx /= L;
            dy /= L;
            float x = POS[0] + dx * dist * u;
            float y = POS[1] + dy * dist * u;
            float aa = a * (1f - u) * (u < 0.15f ? u / 0.15f : 1f);
            prep(Paint.Style.FILL, 0f);
            P.setColor(al(p.color, aa));
            if (hearts) heart(c, x, y, size);
            else c.drawCircle(x, y, size, P);
        }
    }

    // ---- Effects modelled on the reference video ----
    // Positions u run clockwise around the screen edge, starting at the top-left corner.
    // The line is ONE stroke with a sweep gradient whose alpha follows the effect, so fades are smooth.
    static final int K = 240;
    static final int[] SC = new int[K + 1];
    static final float[] SP = new float[K + 1];
    static final float[] SU = new float[K + 1];
    static int suW, suH;
    static final float SOFT = 0.08f;
    static final float[] LWS = {2.8f, 1.8f, 1f};
    static final float[] LAS = {0.07f, 0.12f, 1f};

    static {
        for (int j = 0; j <= K; j++) SP[j] = j / (float) K;
    }

    static float circ(float x) {
        x -= Math.round(x);
        return Math.abs(x);
    }

    static float win(float s, float d, float on) {
        return Math.min(ease((s - d) / SOFT), ease((d + on - s) / SOFT));
    }

    static float bump(float d) {
        float hw = 0.07f;
        if (d >= hw) return 0f;
        float x = 1f - (d / hw) * (d / hw);
        return x * x;
    }

    // Edge position (0..1 clockwise from the top-left corner) for every gradient stop angle.
    static void updateU(int w, int h) {
        if (suW == w && suH == h) return;
        suW = w;
        suH = h;
        float cx = w / 2f, cy = h / 2f, per = 2f * (w + h);
        for (int j = 0; j <= K; j++) {
            double th = 2.0 * Math.PI * j / K;
            float dx = (float) Math.cos(th), dy = (float) Math.sin(th);
            float tx = Math.abs(dx) < 1e-6f ? 1e9f : cx / Math.abs(dx);
            float ty = Math.abs(dy) < 1e-6f ? 1e9f : cy / Math.abs(dy);
            float tt = Math.min(tx, ty);
            float x = cx + dx * tt, y = cy + dy * tt;
            float u;
            if (ty <= tx) u = dy < 0 ? x / per : (w + h + (w - x)) / per;
            else u = dx > 0 ? (w + y) / per : (2f * w + h + (h - y)) / per;
            SU[j] = u;
        }
    }

    static int palAt(FxP p, float f) {
        if (p.lineColors == null) return p.color;
        int[] pal = p.lineColors;
        float x = cl(f) * (pal.length - 1);
        int i = Math.min((int) x, pal.length - 2);
        float k = x - i;
        int a = pal[i], b = pal[i + 1];
        int r = (int) (((a >> 16) & 255) * (1f - k) + ((b >> 16) & 255) * k);
        int g = (int) (((a >> 8) & 255) * (1f - k) + ((b >> 8) & 255) * k);
        int bl = (int) ((a & 255) * (1f - k) + (b & 255) * k);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    // rotate, shimmer, gravity, eclipse, eclipse light, center glow, flash.
    static void flowLine(Canvas c, int w, int h, FxP p, float a, String fx, float t) {
        float inset = p.lineW / 2f + 1f;
        updateU(w, h);
        float per = 2f * (w + h);
        float delay = 0.5f, on = 0.5f;
        if ("eclipselight".equals(fx)) {
            delay = 0.6f;
            on = 0.33f;
        } else if ("centerglow".equals(fx)) {
            on = 0.55f;
        }
        float s = t * (delay + on + SOFT);
        float g1 = 0.1f + t, g2 = g1 + 0.5f;
        float ub = (1.5f * w + h) / per;
        float fade = 1f - ease((t - 0.85f) / 0.15f);
        float maxd = 0.5f * Math.max(w, h) / per;
        float m0 = 0.5f * w / per, m1 = (w + 0.5f * h) / per;
        float m2 = (1.5f * w + h) / per, m3 = (2f * w + 1.5f * h) / per;
        boolean any = false;
        for (int j = 0; j <= K; j++) {
            float u = SU[j];
            float v;
            if ("rotate".equals(fx)) {
                float r = u - t;
                r -= (float) Math.floor(r);
                v = ease(r / 0.04f) * ease((0.52f - r) / 0.04f);
            } else if ("gravity".equals(fx)) {
                v = win(s, delay * u, on);
            } else if ("eclipse".equals(fx) || "eclipselight".equals(fx)) {
                v = win(s, delay * 2f * Math.min(u, 1f - u), on);
            } else if ("centerglow".equals(fx)) {
                float best = Math.min(Math.min(circ(u - m0), circ(u - m1)), Math.min(circ(u - m2), circ(u - m3)));
                v = win(s, delay * Math.min(1f, best / maxd), on);
            } else if ("shimmer".equals(fx)) {
                float q1 = 1f - ease((circ(u - g1) - 0.02f) / 0.08f);
                float q2 = 1f - ease((circ(u - g2) - 0.02f) / 0.08f);
                v = 1f - Math.max(q1, q2);
            } else {
                float ua = ub - 0.5f * t, ud = ub + 0.5f * t;
                v = Math.max(bump(circ(u - ua)), bump(circ(u - ud))) * fade * ease(t / 0.08f);
            }
            SC[j] = al(palAt(p, SP[j]), v);
            if (v > 0.01f) any = true;
        }
        if (!any) return;
        SweepGradient g = new SweepGradient(w / 2f, h / 2f, SC, SP);
        R.set(inset, inset, w - inset, h - inset);
        float rr = Math.max(0f, p.corner - inset);
        for (int l = 0; l < 3; l++) {
            prep(Paint.Style.STROKE, p.lineW * LWS[l]);
            P.setShader(g);
            P.setAlpha((int) (255 * cl(a * LAS[l])));
            c.drawRoundRect(R, rr, rr, P);
        }
    }

    // Time used for the static thumbnails so the visible corner is lit.
    static float thumbT(String fx) {
        float l = 1.08f;
        if ("gravity".equals(fx)) return 0.375f / l;
        if ("eclipse".equals(fx)) return 0.5f / l;
        if ("eclipselight".equals(fx)) return 0.465f / 1.01f;
        if ("centerglow".equals(fx)) return 0.5f / 1.13f;
        if ("shimmer".equals(fx)) return 0.4f;
        if ("rotate".equals(fx)) return 0.92f;
        if ("flash".equals(fx)) return 0.66f;
        if ("pulse".equals(fx)) return 0.5f;
        return 0.42f;
    }

    static void draw(Canvas c, int w, int h, FxP p, float t, float k) {
        float a = k * p.alpha;
        if (a <= 0.003f || w <= 0 || h <= 0) return;
        String fx = p.fx;
        float d = p.d;
        float inset = p.lineW / 2f + 1f;
        float ang = 360f * t * 0.7f;
        if ("basic".equals(fx)) {
            basic(c, w, h, p, a, ang);
        } else if ("glow".equals(fx)) {
            for (int i = 16; i >= 1; i--) {
                edgeLine(c, w, h, p, 2f * p.depth * i / 16f, a * 0.075f, 0f, ang);
            }
        } else if ("wave".equals(fx)) {
            edgeLine(c, w, h, p, p.lineW, a, inset, ang);
            for (int j = 0; j < 3; j++) {
                float u = t * 1.5f - j * 0.2f;
                if (u < 0f || u > 1f) continue;
                edgeLine(c, w, h, p, p.lineW * (1f - 0.4f * u), a * (1f - u) * 0.9f,
                        inset + u * 40f * d, ang);
            }
        } else if ("bubble".equals(fx) || "heart".equals(fx)) {
            if (p.edge) basic(c, w, h, p, a, ang);
            particles(c, w, h, p, t, a, "heart".equals(fx));
        } else if ("shimmer".equals(fx)) {
            flowLine(c, w, h, p, a, fx, t);
        } else if ("pulse".equals(fx)) {
            float br = (float) (0.5 - 0.5 * Math.cos(2.0 * Math.PI * t * 2.0));
            for (int i = 4; i >= 1; i--) {
                edgeLine(c, w, h, p, p.lineW * (1f + i * 0.9f) * (0.8f + 0.6f * br),
                        a * 0.07f * (0.6f + 0.8f * br), inset, ang);
            }
            edgeLine(c, w, h, p, p.lineW, a, inset, ang);
        } else if ("rotate".equals(fx)) {
            flowLine(c, w, h, p, a, fx, t);
        } else if ("gravity".equals(fx) || "eclipse".equals(fx) || "eclipselight".equals(fx)
                || "centerglow".equals(fx) || "flash".equals(fx)) {
            flowLine(c, w, h, p, p.alpha, fx, t);
        }
    }
}

class FxView extends View {
    final SharedPreferences sp;
    final boolean thumb;
    final String fxId;
    final float density;
    FxP p;
    long start;
    boolean running;
    boolean ring;
    final Paint rp = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Path clip = new Path();
    final RectF rect = new RectF();

    final Runnable loop = new Runnable() {
        public void run() {
            if (!running) return;
            invalidate();
            postOnAnimation(this);
        }
    };

    FxView(Context c, SharedPreferences sp, boolean thumb, String fxId) {
        super(c);
        this.sp = sp;
        this.thumb = thumb;
        this.fxId = fxId;
        this.density = c.getResources().getDisplayMetrics().density;
        reload();
    }

    void reload() {
        p = FxP.load(sp, density, 0);
        if (thumb) {
            p.fx = fxId;
            p.d = density * 0.8f;
            p.lineW = 2.4f * density;
            p.corner = 16f * density;
            p.depth = 5f * density;
            p.alpha = 1f;
        }
    }

    void restart() {
        reload();
        start = SystemClock.uptimeMillis();
        invalidate();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (!thumb) {
            running = true;
            start = SystemClock.uptimeMillis();
            postOnAnimation(loop);
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        running = false;
        super.onDetachedFromWindow();
    }

    @Override
    protected void onDraw(Canvas c) {
        if (thumb) {
            // Only the top-right corner of a bigger virtual screen is shown, like the system picker.
            float vw = getWidth() * 1.8f, vh = getHeight() * 1.8f;
            float rad = 18f * density;
            float in = ring ? 2.5f * density : 0f;
            clip.reset();
            rect.set(in, in, getWidth() - in, getHeight() - in);
            clip.addRoundRect(rect, rad - in, rad - in, Path.Direction.CW);
            c.save();
            c.clipPath(clip);
            c.translate(getWidth() - vw - 6f * density, 6f * density);
            Fx.draw(c, (int) vw, (int) vh, p, Fx.thumbT(p.fx), 1f);
            c.restore();
            if (ring) {
                float h2 = 1.25f * density;
                rp.setStyle(Paint.Style.STROKE);
                rp.setStrokeWidth(2.5f * density);
                rp.setColor(Color.WHITE);
                rect.set(h2, h2, getWidth() - h2, getHeight() - h2);
                c.drawRoundRect(rect, rad - h2, rad - h2, rp);
            }
            return;
        }
        int in = 300, out = 500, hold = FxP.holdMs(sp), pause = 700;
        int pass = in + hold + out;
        int active = pass * FxP.repeats(sp);
        long ms = (SystemClock.uptimeMillis() - start) % (active + pause);
        if (ms >= active) return;
        float f;
        if (ms < in) f = ms / (float) in;
        else if (ms >= active - out) f = (active - ms) / (float) out;
        else f = 1f;
        Fx.draw(c, getWidth(), getHeight(), p, (ms % pass) / (float) pass, Fx.ease(f));
    }
}

class GlowView extends View {
    final FxP p;
    final Handler h = new Handler(Looper.getMainLooper());
    float k, t;
    long start;
    int tin, thold, tout, reps = 1;
    boolean running;
    Runnable endCb;
    int cTicks, hTicks, draws, drawCalls;

    void step() {
        long ms = SystemClock.uptimeMillis() - start;
        int pass = tin + thold + tout;
        int total = pass * reps;
        if (ms >= total) {
            finish();
            return;
        }
        // fade in only at the very start and fade out only at the very end; every pass replays the motion
        float f;
        if (ms < tin) f = ms / (float) tin;
        else if (ms >= total - tout) f = (total - ms) / (float) tout;
        else f = 1f;
        k = Fx.ease(f);
        t = (ms % pass) / (float) pass;
        invalidate();
    }

    final Choreographer.FrameCallback cb = new Choreographer.FrameCallback() {
        public void doFrame(long frameTimeNanos) {
            if (!running) return;
            cTicks++;
            step();
            if (running) Choreographer.getInstance().postFrameCallback(this);
        }
    };

    final Runnable hstep = new Runnable() {
        public void run() {
            if (!running) return;
            hTicks++;
            step();
            if (running) h.postDelayed(this, 16);
        }
    };

    final Runnable safety = new Runnable() {
        public void run() {
            if (running) finish();
        }
    };

    void finish() {
        running = false;
        Choreographer.getInstance().removeFrameCallback(cb);
        h.removeCallbacks(hstep);
        h.removeCallbacks(safety);
        if (endCb != null) endCb.run();
    }

    GlowView(Context c, FxP p) {
        super(c);
        this.p = p;
    }

    void play(int in, int hold, int out, int repeats, Runnable end) {
        tin = in;
        thold = hold;
        tout = out;
        reps = Math.max(1, repeats);
        endCb = end;
        start = SystemClock.uptimeMillis();
        cTicks = 0;
        hTicks = 0;
        draws = 0;
        drawCalls = 0;
        running = true;
        Choreographer.getInstance().postFrameCallback(cb);
        h.postDelayed(hstep, 16);
        h.postDelayed(safety, (long) (in + hold + out) * reps + 300);
    }

    void stop() {
        running = false;
        Choreographer.getInstance().removeFrameCallback(cb);
        h.removeCallbacks(hstep);
        h.removeCallbacks(safety);
    }

    @Override
    protected void onDetachedFromWindow() {
        running = false;
        super.onDetachedFromWindow();
    }

    @Override
    protected void onDraw(Canvas c) {
        drawCalls++;
        if (k <= 0f) return;
        draws++;
        Fx.draw(c, getWidth(), getHeight(), p, t, k);
    }
}
