package com.bxt.edgeglow;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;

/** One UI style building blocks: colors, haptics, switch and radio button. */
final class Oui {
    static final int BLUE = 0xFF3879FE;
    static final int TRACK_OFF = 0xFF636368;
    static final int RING_OFF = 0xFF8A8A8F;
    static final int CARD = 0xFF1C1C1F;
    static final int DIVIDER = 0xFF343437;
    static final int TEXT = 0xFFFFFFFF;
    static final int BTN = 0xFF2D2D30;
    static final int BTN_PRESSED = 0xFF3C3C40;

    private Oui() {}

    static void tick(View v) {
        v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
    }

    static void tap(View v) {
        v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
    }

    static int lerp(int a, int b, float t) {
        if (t < 0f) t = 0f;
        if (t > 1f) t = 1f;
        int r = (int) (((a >> 16) & 255) * (1f - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1f - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1f - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    /** One UI switch: 36x21dp track, 17dp thumb that shrinks with a soft halo while pressed. */
    static class Switch extends View {
        interface Listener {
            void onChanged(boolean on);
        }

        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private final float d;
        private boolean checked;
        private float pos;
        private float press;
        private ValueAnimator posA, pressA;
        private Listener listener;

        Switch(Context c) {
            super(c);
            d = c.getResources().getDisplayMetrics().density;
        }

        void setListener(Listener l) {
            listener = l;
        }

        void setChecked(boolean on) {
            checked = on;
            pos = on ? 1f : 0f;
            invalidate();
        }

        boolean isChecked() {
            return checked;
        }

        void toggle() {
            checked = !checked;
            animPos(checked ? 1f : 0f);
            Oui.tick(this);
            if (listener != null) listener.onChanged(checked);
        }

        @Override
        protected void onMeasure(int w, int h) {
            setMeasuredDimension((int) (44 * d), (int) (36 * d));
        }

        @Override
        public void setPressed(boolean pressed) {
            super.setPressed(pressed);
            animPress(pressed ? 1f : 0f);
        }

        private void animPos(float to) {
            if (posA != null) posA.cancel();
            posA = ValueAnimator.ofFloat(pos, to);
            posA.setDuration(220);
            posA.setInterpolator(new DecelerateInterpolator());
            posA.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                public void onAnimationUpdate(ValueAnimator a) {
                    pos = (Float) a.getAnimatedValue();
                    invalidate();
                }
            });
            posA.start();
        }

        private void animPress(float to) {
            if (pressA != null) pressA.cancel();
            pressA = ValueAnimator.ofFloat(press, to);
            pressA.setDuration(130);
            pressA.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                public void onAnimationUpdate(ValueAnimator a) {
                    press = (Float) a.getAnimatedValue();
                    invalidate();
                }
            });
            pressA.start();
        }

        @Override
        protected void onDraw(Canvas c) {
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            float tw = 36 * d, th = 21 * d;
            float l = cx - tw / 2f, t = cy - th / 2f;
            p.setStyle(Paint.Style.FILL);
            p.setColor(Oui.lerp(Oui.TRACK_OFF, Oui.BLUE, pos));
            r.set(l, t, l + tw, t + th);
            c.drawRoundRect(r, th / 2f, th / 2f, p);
            float x0 = l + 10.5f * d, x1 = l + tw - 10.5f * d;
            float tx = x0 + (x1 - x0) * pos;
            if (press > 0.01f) {
                p.setColor(((int) (0x38 * press) << 24) | 0xFFFFFF);
                c.drawCircle(tx, cy, 13.5f * d, p);
            }
            p.setColor(0xFFFCFCFF);
            c.drawCircle(tx, cy, (8.5f - 2.2f * press) * d, p);
        }
    }

    /** One UI radio button: gray ring, blue ring with a growing dot when selected. */
    static class Radio extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float d;
        private boolean checked;
        private float sel;
        private float press;
        private ValueAnimator selA, pressA;

        Radio(Context c) {
            super(c);
            d = c.getResources().getDisplayMetrics().density;
        }

        boolean isChecked() {
            return checked;
        }

        void setChecked(boolean on, boolean animate) {
            if (on == checked && animate) return;
            checked = on;
            if (!animate) {
                sel = on ? 1f : 0f;
                invalidate();
                return;
            }
            if (selA != null) selA.cancel();
            selA = ValueAnimator.ofFloat(sel, on ? 1f : 0f);
            selA.setDuration(on ? 260 : 140);
            selA.setInterpolator(on ? new OvershootInterpolator(1.4f) : new DecelerateInterpolator());
            selA.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                public void onAnimationUpdate(ValueAnimator a) {
                    sel = (Float) a.getAnimatedValue();
                    invalidate();
                }
            });
            selA.start();
        }

        @Override
        protected void onMeasure(int w, int h) {
            setMeasuredDimension((int) (30 * d), (int) (30 * d));
        }

        @Override
        public void setPressed(boolean pressed) {
            super.setPressed(pressed);
            if (pressA != null) pressA.cancel();
            pressA = ValueAnimator.ofFloat(press, pressed ? 1f : 0f);
            pressA.setDuration(130);
            pressA.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                public void onAnimationUpdate(ValueAnimator a) {
                    press = (Float) a.getAnimatedValue();
                    invalidate();
                }
            });
            pressA.start();
        }

        @Override
        protected void onDraw(Canvas c) {
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            float s = Math.max(0f, Math.min(1f, sel));
            if (press > 0.01f) {
                p.setStyle(Paint.Style.FILL);
                p.setColor(((int) (0x2A * press) << 24) | 0xFFFFFF);
                c.drawCircle(cx, cy, 15f * d, p);
            }
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth((1.6f + 0.7f * s) * d);
            p.setColor(Oui.lerp(Oui.RING_OFF, Oui.BLUE, s));
            c.drawCircle(cx, cy, 9.6f * d, p);
            if (sel > 0.01f) {
                p.setStyle(Paint.Style.FILL);
                p.setColor(Oui.BLUE);
                c.drawCircle(cx, cy, 5.3f * d * sel, p);
            }
        }
    }
}
